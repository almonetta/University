# Programación contra bases de datos

## JDBC

Este proyecto contiene la plantilla de código fuente para realizar el Apartado 3 de la asignatura de Bases de Datos en el Curso Académico 2023-2024. Podrás encontrar más información sobre la misma en el Moodle de la asignatura.